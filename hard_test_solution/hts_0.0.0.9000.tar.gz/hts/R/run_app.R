#' Launch Shiny App for WorldClim BIO1 Workflow (Medium Test Solution)
#'
#' This function launches a Shiny application that demonstrates a
#' reproducible geospatial workflow using \pkg{terra}, \pkg{geodata},
#' \pkg{sf}, and \pkg{shiny}.
#'
#' The app performs the following steps after clicking the **Run** button:
#' \enumerate{
#'   \item Downloads WorldClim bioclimatic variables at 10 arc-minute resolution.
#'   \item Extracts BIO1 (Annual Mean Temperature).
#'   \item Crops BIO1 to the spatial extent of South America.
#'   \item Masks BIO1 using the South America boundary shapefile.
#'   \item Plots results after each processing step.
#' }
#'
#' The South America boundary shapefile must be available locally at:
#' \code{./data/south_america/vc965bq8111.shp}
#'
#' @details
#' WorldClim data are downloaded temporarily using \code{geodata::worldclim_global()}
#' and stored in \code{tempdir()}. The app uses reactive programming via
#' \code{observeEvent()} to trigger computation and plotting.
#'
#' @return
#' A \code{shiny.appobj} object that launches an interactive Shiny application.
#'
#' @seealso
#' \code{\link[geodata]{worldclim_global}},
#' \code{\link[terra]{crop}},
#' \code{\link[terra]{mask}},
#' \code{\link[shiny]{shinyApp}}
#'
#' @examples
#' \dontrun{
#' run_app()
#' }
#'
#' @import shiny
#' @import terra
#' @import geodata
#' @import sf
#'
#' @export
run_app <- function(){
  # 2. Build a Shiny interface that performs the workflow from the Easy test.
  ui <- pageWithSidebar(
    headerPanel("Medium Test Solution"),

    sidebarPanel(

      tags$p("Press the button to run the workflow below:"),
      tags$ul(
        tags$li("1. Download WorldClim bioclimatic variables at 10 arc minute resolution"),
        tags$li("2. Extract BIO1 (Annual Mean Temperature) from the dataset"),
        tags$li("3. Crop BIO1 to an extent covering South America"),
        tags$li("4. Mask BIO1 to South America"),
        tags$li("5. Plot the processed raster at each step")
      ),

      actionButton(
        inputId = "run",
        label = "Run",
        icon = icon("play")
      )
    ),

    mainPanel(
      plotOutput(outputId = "step1"),
      plotOutput(outputId = "step2"),
      plotOutput(outputId = "step3"),
      plotOutput(outputId = "step4")
    )
  )

  server <- function(input, output, session) {

    observeEvent(input$run, {

      showNotification("The workflow has begun computing!",
                       duration = 3,
                       type = "message")

      # 1. Download WorldClim bioclimatic variables
      bio_data <- geodata::worldclim_global(var = "bio", res = 10, path = tempdir())

      # 2. Extract BIO1 (Annual Mean Temperature)
      bio1 <- bio_data[[1]]

      # 3. Read South America boundary
      south_america <- sf::st_read("./data/south_america/vc965bq8111.shp", quiet = TRUE)
      south_america <- terra::vect(south_america)

      # 4. Crop and mask
      bio1_cropped <- terra::crop(x = bio1, y = south_america)
      bio1_cropped_masked <- terra::mask(x = bio1_cropped, mask = south_america)

      # Plots
      output$step1 <- renderPlot({
        plot(bio_data)
      })

      output$step2 <- renderPlot({
        plot(bio1, main = "Step 2. BIO1 (Annual Mean Temperature)")
      })

      output$step3 <- renderPlot({
        plot(bio1_cropped, main = "Step 3. BIO1 cropped to South America")
      })

      output$step4 <- renderPlot({
        plot(bio1_cropped_masked, main = "Step 4. BIO1 cropped and masked to South America")
      })

    })
  }

  # Run the app
  shinyApp(ui = ui, server = server)

}
